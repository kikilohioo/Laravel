<?php $__env->startSection('content'); ?>
	<h1><?php echo e($product->title); ?> (#<?php echo e($product->id); ?>)</h1>
	<h3>Price: $ <?php echo e($product->price); ?></h3>
	<p>Description: <?php echo e($product->description); ?></p>
	<p>Status: <?php echo e($product->status); ?></p>
	<p>Stock: <?php echo e($product->stock); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\e-mercado\resources\views/products/show.blade.php ENDPATH**/ ?>