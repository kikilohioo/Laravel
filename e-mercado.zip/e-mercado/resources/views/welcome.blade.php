@extends('layouts.app')
@section('content')
	<h1>Welcome to e-Mercado</h1>
    <h4>Let's start!</h4>
@endsection