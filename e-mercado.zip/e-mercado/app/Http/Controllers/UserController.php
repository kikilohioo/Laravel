<?php

namespace App\Http\Controllers;

use App\Models\User;

class UserController extends Controller
{
    //Controlador de usuarios
    public function __construct()
    {
        //$this->middleware('auth')->except('index');
    }

    public function index()
    {
        //mostrar todos los usuarios
        $users = User::all()->toArray();

        return $users;
    }

    public function show(User $user)
    {
        return $user;
    }

    public function update(User $user)
    {
        $user = user::findOrFail($user);

        $user->update(request()->validated());

        return $user;
    }

    public function destroy(User $user)
    {
        //eliminar un campeonato
        //$user = user::findOrFail($user);

        $user->delete();

        return $user;
    }
}
