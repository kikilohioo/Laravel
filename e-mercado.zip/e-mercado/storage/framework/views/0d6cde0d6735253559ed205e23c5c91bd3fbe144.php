<?php $__env->startSection('content'); ?>
	<h1>Edit a Product</h1>
	<form method="POST" action="<?php echo e(route('products.update', ['product' => $product->id])); ?>">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="form-row">
			<label>Title</label>
			<input class="form-control" type="text" value="<?php echo e(old('title') ?? $product->title); ?>" name="title" required>
		</div>
		<div class="form-row">
			<label>Description</label>
			<input class="form-control" type="text" value="<?php echo e(old('description') ?? $product->description); ?>" name="description" required>
		</div>
		<div class="form-row">
			<label>Price</label>
			<input class="form-control" type="number" value="<?php echo e(old('titpricele') ?? $product->price); ?>" min="1.00" step="0.01" name="price" required>
		</div>
		<div class="form-row">
			<label>Stock</label>
			<input class="form-control" type="number" value="<?php echo e(old('stock') ?? $product->stock); ?>" min="0" name="stock" required>
		</div>
		<div class="form-row my-3">
			<label>Status</label>
			<select class="custom-select" name="status">
				<option <?php echo e(old('status') == 'available' ? 'selected' : ($product->status == 'available' ? 'selected' : '')); ?> value="available">Available</option>
				<option <?php echo e(old('status') == 'available' ? 'selected' : ($product->status == 'unavailable' ? 'selected' : '')); ?> value="unavailable">Unavailable</option>
			</select>
		</div>
		<div class="form-row">
			<button type="submit" class="btn btn-primary btn-lg">Edit Product</button>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\e-mercado\resources\views/products/edit.blade.php ENDPATH**/ ?>